
CREATE TABLE scoretable (
    id TEXT PRIMARY KEY,
    col1 TEXT ,
    col2 TEXT ,
    col3 TEXT ,
    col4 TEXT ,
    col5 TEXT ,
    col6 TEXT ,
    col7 TEXT ,
    col8 TEXT ,
    col9 TEXT ,
    col10 TEXT ,
    col11 TEXT ,
    col12 TEXT ,
    col13 TEXT ,
    col14 TEXT ,
    col15 TEXT 
);